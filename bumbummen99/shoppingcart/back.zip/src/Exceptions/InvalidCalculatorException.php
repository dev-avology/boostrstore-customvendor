<?php

namespace Gloudemans\Shoppingcart\Exceptions;

use RuntimeException;

class InvalidCalculatorException extends RuntimeException
{
}
