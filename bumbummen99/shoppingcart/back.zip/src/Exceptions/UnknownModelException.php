<?php

namespace Gloudemans\Shoppingcart\Exceptions;

use RuntimeException;

class UnknownModelException extends RuntimeException
{
}
